#!/bin/bash
cat wowhead_web.txt | grep "Tea Tales"
